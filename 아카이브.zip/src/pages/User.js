


import React, { useEffect, useState } from "react";
import { PostUser } from "../api/user/user_api";

const LogIn = () => {
//   const [userPost, setUserPost] = useState([]);

const handleClickUser = (e) => {
    const obj = {
      uid: "string",
      upw: "string",
      nm: "string",
      pic: "string",
    };
    PostUser(obj);
    console.log(obj);
  };

  

//   useEffect(() => {
//     PostUser();
//   });

  return (
    //회원 가입
    <div>
      <div>
        <img src="../../images/main_logo.svg" alt="유저사진"></img>
        닉네임 :<input></input>
        <form>
          <label className="user">
            아이디 :
            <input type="text" name="username" className="id" />
          </label>

          <label className="user">
            비밀번호 :
            <input type="text" name="username" className="pw" />
          </label>
          <button
            onClick={(e) => {
              handleClickUser();
            }}
          >
            회원가입
          </button>
        </form>
      </div>
    </div>
  );
};

export default LogIn;