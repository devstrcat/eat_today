import axios from "axios";
import { SERVER_URL } from "../components/meal/config"

export const getMore = async () => {
    try {
        const url = `/api/meal/30`
        const res = await axios.get(url);
        console.log(res.data);
        if(res.data === 200){
            return res.data;
        };
    }catch(error) {
        alert(`${error}가 발생했습니다.`)
    }
    
}; 