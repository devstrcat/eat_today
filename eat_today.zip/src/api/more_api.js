import axios from "axios";
import { SERVER_URL } from "../components/meal/config"

// const mock = {
//     title: "초코케이크",
//     ingredient: "밀가루, 계란, 우유, 초콜렛",
//     recipe: "오븐에 구워준다.",
//     hashtag: ["#초코케이크", "#크리스마스", "#룰루"],
//     comment: "태워버렸다 잉잉"
// };

export const getMore = async() => {
    try {
        const url = `${SERVER_URL}/api/meal/30`
        const res = await axios.get(url);
        console.log(res.data);
        return res;
    // return mock; 
    }catch(error) {
        alert(`${error}가 발생했습니다.`)
    }
}; 