import React, { useEffect, useState } from 'react'
import Footer from '../components/Footer';
import { BtWrap, CakeImg, ContentWrap, HashTagWrap, HeaderWrap, MoreMainWrap, MoreWrap, Title } from '../styles/more/moreStyle';
import Search from '../components/Search';
import { getMore } from '../api/more_api';

const RecipeMore = () => {
  const [more, setMore] = useState(
    // initialize = 초기값 셋팅
    {
      "imeal": 30,
      "title": "스파게티",
      "review": "맛있었다",
      "createdAt": "2023-12-14 12:54:00",
      "pics": [
        "https://i.namu.wiki/i/lr2V-3TTyfhyeRB7Ovhi9CSfxAOOHwfXxei63rf9udC8vJwbOevFk6jGr8wRpHwaUcqfpgGEpTO781442-VLTSxMcE0xkP7somI7myWLY3-Gwt1PbkhN9ZIWGWOexofkIQJaBgP3MtJvlKFJBONDSA.webp"
      ],
      "tags": [
        "string"
      ],
      "recipe": "삶기",
      "ingredient": "면",
      "bookMark": 0
  }
  ); 
  
  // 최초 렌더링 시 실행
  useEffect(() => {
    setMore(getMore());
    console.log(more);
  },[]);

  
  return (
    <MoreWrap>
      <Search></Search>
            <HeaderWrap>
            <Title>{more.title}</Title>
                <BtWrap>
                  <button className='edit'>
                  </button>
                  <button className='trash'>   
                  </button>
                </BtWrap>
                </HeaderWrap>
        <MoreMainWrap>
            <CakeImg src='/images/chocolate.svg'/>
            <HashTagWrap>
              {more.hashtag.map((item, index)=> {
                return <li key={index}>{item}</li>
              })}
            </HashTagWrap>
            <ContentWrap>
              <div className='ingredient'>{more.ingredient}</div>
              <div className='recipe'>{more.recipe}</div>
              <div className='comment'>{more.comment}</div>
            </ContentWrap>
        </MoreMainWrap>
        <Footer />
    </MoreWrap>
  )
};

export default RecipeMore;
