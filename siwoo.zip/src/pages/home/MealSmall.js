import React from "react";

const MealSmall = () => {
  return (
    <div>
      <header>search</header>
      <main>group</main>
      <footer>button_bar</footer>
    </div>
  );
};

export default MealSmall;
