import React from "react";

const Index = () => {
  return (
    <div>
      <h2>Index</h2>
    </div>
  );
};

export default Index;
